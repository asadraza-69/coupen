<?php include 'header.php'?>



<section class="top-store-category-sec sec-padding">
        <div class="container">
                <div class="content-entry">
                    <div class="accordion-title">
                        <h4>All Stores</h4>
                    </div>
                        <div class="product-tiles">
                            <div class="row">
                            
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/sakara_Logo.png"
                                                        />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/Perfect_Bar.png"
                                                        />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/morrisons_discount_code.png"
                                                         />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/allplants_discount_code.png"
                                                         />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/goldbelly_promo_code.png"
                                                         />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/tobleronecouponcode.png"
                                                        />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                    <div class="col-lg-3 col-md-4">
                                        <a href="../coupon.html">
                                            <div class="mainbox">
                                                <div class="imgbox">
                                                    <img class="w-100" src="uploads/store/alohacouponcode_copy1.png"
                                                         />
                                                </div>
                                                <div class="contentbox">
                                                    <span></span>
                                                    <p></p>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> 



<?php include 'footer.php'?>