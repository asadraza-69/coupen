<?php include 'header.php'?>

 <!-- Banner Section Start -->
      <!-- Header Section Start -->
      <!-- Store Section Start -->
      <style>
         ol{
         margin-left: 21px;
         }
         .coupons-tiles .coupon-content span{
         font-size: 14px;
         text-transform: uppercase;
         color: var(--primary-color);
         font-weight: bold;
         }
         .store-sidebar h3 {
         font-size: 17px;
         }
         .store-sidebar .hints-tips ul {
         font-weight: 400;
         }
      </style>
      <section class="store-sec sec-padding">
         <div class="container">
            <div class="row">
               <div class="col-lg-3">
                  <div class="main-sidebar">
                     <a class="store-img" href="#">
                     <img class="w-100" src="uploads/store/vonhaus_logo.png" alt="Vonhaus  coupons and coupon codes" />
                     </a>
                     <span class="store-short-desc"><a class="show-more" href="javascript:;">Show more</a></span>
                     <div class="store-sidebar">
                        <div class="available-offers">
                           <p>Coupon Type</p>
                           <div class="available-options">
                              <label>
                              <input name="offer_type" type="radio" class="slectOne" id="all" data-id="all" checked>
                              <span>All Offers</span>
                              </label>
                              <label>
                              <input name="offer_type" type="radio" class="slectOne" data-id="online">
                              <span>Coupons</span>
                              </label>
                              <label>
                              <input name="offer_type" type="radio" class="slectOne" data-id="offline">
                              <span>Deals</span>
                              </label>
                           </div>
                        </div>
                        <div class="available-offers">
                           <div style="font-size: 20px; font-weight: 500px;">6 offers available</div>
                        </div>
                        <div class="today-top-offers">
                           <h3 style="font-size: 16px;">Todays Vonhaus  Top Offers:</h3>
                           <ul class="top-offer-content">
                              <li><a href="javascript:;" data-offer_id="8473"  href="javascript:;" class="offer_anchor">10% Off On Your First Order</a></li>
                              <li><a href="javascript:;" data-offer_id="8471"  href="javascript:;" class="offer_anchor">Up To 50% Off On Clearance Items</a></li>
                              <li><a href="javascript:;" data-offer_id="8469"  href="javascript:;" class="offer_anchor">Up To 40% Off On Outdoor Living </a></li>
                           </ul>
                           <ul class="top-offer-list list-unstyled">
                              <li class="title">Total Offers</li>
                              <li class="content">6 </li>
                              <li class="title">Coupon Codes</li>
                              <li class="content">1</li>
                              <li class="title"> Deals</li>
                              <li class="content">5</li>
                           </ul>
                           <ul class="store_content">
                              <li class="content">
                                 <span><a href="index.html">Home</a> › <a href="category/furniture-%26-decor.html">Furniture & Decor</a> › <a><span style="font-weight: 800;display: inline;">Vonhaus <span></a></span>
                              </li>
                           </ul>
                        </div>
                        <div class="social-media-store-kit">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-lg-9 main-contentbar">
                  <div class="tile-mainbox">
                     <div class="store-img">
                        <img src="uploads/store/vonhaus_logo.png" alt="#" />
                     </div>
                     <div class="sec-title">
                        <h1>Vonhaus Discount Code 2023</h1>
                        <ul class="list-unstyled d-flex">
                           <li>Delivery</li>
                           <li>Free Shipping</li>
                        </ul>
                     </div>
                  </div>
                  <div class="desktop-coupon-tiles">
                     <div id="all" style="display:block;" class="coupons-tiles all">
                        <div class="coupon-tile">
                           <div class="discount-percentage">
                              <h4> -10%</h4>
                           </div>
                           <div class="coupon-content">
                              <span>code</span>
                              <p>10% Off On Your First Order</p>
                              <div class="verified">
                              </div>
                           </div>
                           <div  class="getcodebtn">
                              <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                              <span>EQ2</span>
                           </div>
                        </div>
                        <div class="coupon-tile">
                           <div class="discount-percentage">
                              <h4> -50%</h4>
                           </div>
                           <div class="coupon-content">
                              <span>deal</span>
                              <p>Up To 50% Off On Clearance Items</p>
                              <div class="verified">
                              </div>
                           </div>
                           <div  class="getcodebtn">
                              <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                              <span>EQ2</span>
                           </div>
                        </div>
                     
                     </div>
                     <div id="online" style="display:none;" class="coupons-tiles online">
                        <div class="coupon-tile">
                           <div class="discount-percentage">
                              <h4> -10%</h4>
                           </div>
                           <div class="coupon-content">
                              <span>code</span>
                              <p>10% Off On Your First Order</p>
                              <div class="verified">
                              </div>
                           </div>
                           <div  class="getcodebtn">
                              <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                              <span>EQ2</span>
                           </div>
                        </div>
                     </div>
                     <div id="offline" style="display:none;" class="coupons-tiles offline">
                        <div class="coupon-tile">
                           <div class="discount-percentage">
                              <h4> -50%</h4>
                           </div>
                           <div class="coupon-content">
                              <span>deal</span>
                              <p>Up To 50% Off On Clearance Items</p>
                              <div class="verified">
                              </div>
                           </div>
                           <div class="getdealbtn">
                           <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                           </div>
                        </div>
                        <div class="coupon-tile">
                           <div class="discount-percentage">
                              <h4> -40%</h4>
                           </div>
                           <div class="coupon-content">
                              <span>deal</span>
                              <p>Up To 40% Off On Outdoor Living </p>
                              <div class="verified">
                              </div>
                           </div>
                           <div class="getdealbtn">
                           <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                           </div>
                        </div>
                       
                     </div>
                  </div>
                  <div class="store-tabbing mobile-tabbing">
                     <div class="tabs">
                        <ul>
                           <li data-tab="tab-1">All Offers</li>
                           <li data-tab="tab-2">Coupons</li>
                           <li data-tab="tab-3">Deals</li>
                        </ul>
                     </div>
                     <span class="store-short-desc">When you buy through links on Retailescaper we may earn a
                     commission. <a href="#">Learn
                     More</a></span>
                     <div class="tabbing-content">
                        <div class="tab-content" id="tab-1">
                           <div class="coupons-tiles">
                              <div class="coupon-tile">
                                 <div class="discount-percentage">
                                    <h4> -10%</h4>
                                 </div>
                                 <div class="coupon-content">
                                    <span>code</span>
                                    <p>10% Off On Your First Order</p>
                                    <div class="getcodebtn">
                                    <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                                       <span>EQ2</span>
                                    </div>
                                    <div class="verified">
                                    </div>
                                 </div>
                              </div>
                              <div class="coupon-tile">
                                 <div class="discount-percentage">
                                    <h4> -50%</h4>
                                 </div>
                                 <div class="coupon-content">
                                    <span>deal</span>
                                    <p>Up To 50% Off On Clearance Items</p>
                                    <div class="getdealbtn">
                                    <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                                    </div>
                                    <div class="verified">
                                    </div>
                                 </div>
                              </div>
                              
                              <div class="coupon-tile">
                                 <div class="discount-percentage">
                                    <h4><i class="fas fa-shipping-fast"></i></h4>
                                 </div>
                                 <div class="coupon-content">
                                    <span>deal</span>
                                    <p>Free Delivery On All Orders</p>
                                    <div class="getdealbtn">
                                    <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                                    </div>
                                    <div class="verified">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-content" id="tab-2">
                           <div class="coupons-tiles">
                              <div class="coupon-tile">
                                 <div class="discount-percentage">
                                    <h4> -10%</h4>
                                 </div>
                                 <div class="coupon-content">
                                    <span>code</span>
                                    <p>10% Off On Your First Order</p>
                                    <div class="getcodebtn">
                                    <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                                       <span>EQ2</span>
                                    </div>
                                    <div class="verified">
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="tab-content" id="tab-3">
                           <div class="coupons-tiles">
                              <div class="coupon-tile">
                                 <div class="discount-percentage">
                                    <h4> -50%</h4>
                                 </div>
                                 <div class="coupon-content">
                                    <span>deal</span>
                                    <p>Up To 50% Off On Clearance Items</p>
                                    <div class="getdealbtn">
                                    <a   href="#" data-toggle="modal" data-target="#exampleModal" class="offer_anchor" class="tile-btn">Get Code</a>
                                    </div>
                                    <div class="verified">
                                    </div>
                                 </div>
                              </div>
                             
                              
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="offset-lg-3 col-lg-9 ">
               </div>
            </div>
         </div>
      </section>
      <!-- Store Section End -->
      <style>
         .heading-links a{
         font-size:12px;
         }
      </style>
<?php include "footer.php"?>