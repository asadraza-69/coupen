<?php
include "conn.php";
session_start();
if(isset($_SESSION['admin_id'])) 
{
?>
		<!--**********************************
            Content body start
        ***********************************-->

<?php
$queryc="Select * from category";
$resultc=mysqli_query($conn,$queryc);

$queryct="Select * from coupontype";
$resultct=mysqli_query($conn,$queryct);

$querys="Select * from store";
$results=mysqli_query($conn,$querys);

if(isset($_POST['btnSubmit']))
{
    $per=$_POST['per'];
    $details=$_POST['details'];
    $code=$_POST['code'];
    $link=$_POST['link'];
    $cate=$_POST['cate'];
    $coupontype=$_POST['coupontype'];
    $store=$_POST['store'];
    $query1="insert into coupon(percent, details, code, link, category, coupontype, store)values('$per', '$details', '$code', '$link', '$cate', '$coupontype', '$store')";
    $result1=mysqli_query($conn,$query1);
    if($result1)
    {
//      echo "<script>alert('Assign Added Successfully')</script>";
       header("Location:coupons.php");       
    }else{
         echo mysqli_error($conn);

//        echo "<script>alert('Some Error Occured')</script>";
    }
} 
include "header.php";
?>
        <div class="content-body">
            <div class="container-fluid">
            <div class="row page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active"><a href="home.php">Home</a></li>
						<li class="breadcrumb-item"><a href="categories.php">Coupons</a></li>
						<li class="breadcrumb-item"><a href="#">Add Coupon</a></li>
					</ol>
                </div>


                <div class="row">

<div class="col-xl-12 col-lg-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Input Style</h4>
        </div>
        <div class="card-body">
            <div class="basic-form">
            <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <input type="text" class="form-control input-default " placeholder="Percent" name="per" required>
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control input-default " placeholder="Details" name="details" required>
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control input-default " placeholder="Code" name="code" required>
                    </div>
                    <div class="mb-3">
                        <input type="text" class="form-control input-default " placeholder="Link" name="link" required>
                    </div>
                    <div class="mb-3">
                    <select name="cate" class="form-control input-default ">
        <?php
        while($rowc=mysqli_fetch_array($resultc))
        {
        ?>
        <option disabled><b>Category</b></option>
                <option value="<?php echo $rowc['id'];?>">
                <?php echo $rowc['name'];?>
                </option>
        <?php
        }
        ?>
										</select>
                    </div>
                    <div class="mb-3">
                    <select name="coupontype" class="form-control input-default " >
        <?php
        while($rowct=mysqli_fetch_array($resultct))
        {
        ?>
        <option disabled><b>Coupon Type</b></option>
                <option value="<?php echo $rowct['id'];?>">
                <?php echo $rowct['name'];?>
                </option>
        <?php
        }
        ?>
										</select>
                    </div>
                    <div class="mb-3">
                    <select name="store" class="form-control input-default ">
        <?php
        while($rows=mysqli_fetch_array($results))
        {
        ?>
        <option disabled><b>Store</b></option>
                <option value="<?php echo $rows['id'];?>">
                <?php echo $rows['name'];?>
                </option>
        <?php
        }
        ?>
										</select>

                </div>
                    <!-- <input type="submit" value="Submit" name="btnSubmit" style="border-radius:10px; border-color:lightblue; margin-top:10px;"  > -->

                    <button type="submit" class="btn btn-primary" name="btnSubmit">Add  Category</button>

                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<?php
include "footer.php";
}else{
    ?>
    <a href="index.php"><button>Login First</button></a>
    <?php
  }
  ?>
  
