<?php
    
    $conn = mysqli_connect('localhost','root','','ahmed');

    if(!$conn){
        echo "Failed" . mysqli_error($conn); 
    }


?>